package com.seedsight;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.StagedVertexBuffer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

/**
 * Highlights ore blocks that are already present in the client's loaded chunks.
 * The built-in StructureSeedCracker handles multiplayer seed recovery.
 * This renderer does not predict ore locations in chunks the client has not received.
 */
public final class OreOverlayRenderer {
    private static final int HORIZONTAL_RANGE = 24;
    private static final int VERTICAL_RANGE = 16;
    private static final long RESCAN_INTERVAL_TICKS = 10;

    private static final RenderPipeline THROUGH_WALLS = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(IdentifierHelper.id("pipeline/ore_boxes_through_walls"))
                    .withDepthStencilState(Optional.empty())
                    .build()
    );

    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
    private static final StagedVertexBuffer BUFFER = new StagedVertexBuffer(
            () -> "SeedSight Ore Overlay",
            RenderType.SMALL_BUFFER_SIZE
    );

    private static volatile List<OreBox> oreBoxes = List.of();
    private long lastScanTick = Long.MIN_VALUE;

    public void register() {
        LevelExtractionEvents.END_EXTRACTION.register(this::extractOrePositions);
        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(this::renderOrePositions);
    }

    private void extractOrePositions(LevelExtractionContext context) {
        Minecraft client = Minecraft.getInstance();
        ClientLevel level = client.level;

        if (!SeedSightClient.isXrayEnabled() || level == null || client.player == null) {
            oreBoxes = List.of();
            lastScanTick = Long.MIN_VALUE;
            return;
        }

        long gameTick = level.getGameTime();
        if (lastScanTick == Long.MIN_VALUE || gameTick - lastScanTick >= RESCAN_INTERVAL_TICKS) {
            lastScanTick = gameTick;
            oreBoxes = scanLoadedArea(level, client.player.blockPosition());
        }
    }

    private static List<OreBox> scanLoadedArea(ClientLevel level, BlockPos center) {
        List<OreBox> found = new ArrayList<>();
        int minY = Math.max(level.getMinY(), center.getY() - VERTICAL_RANGE);
        int maxY = Math.min(level.getMaxY() - 1, center.getY() + VERTICAL_RANGE);

        for (int x = center.getX() - HORIZONTAL_RANGE; x <= center.getX() + HORIZONTAL_RANGE; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = center.getZ() - HORIZONTAL_RANGE; z <= center.getZ() + HORIZONTAL_RANGE; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!level.hasChunkAt(pos)) {
                        continue;
                    }

                    OreColor color = getOreColor(level.getBlockState(pos).getBlock());
                    if (color != null) {
                        found.add(new OreBox(x, y, z, color.red, color.green, color.blue));
                    }
                }
            }
        }

        return List.copyOf(found);
    }

    private static OreColor getOreColor(Block block) {
        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) {
            return new OreColor(0.10f, 0.90f, 1.00f);
        }
        if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) {
            return new OreColor(0.10f, 1.00f, 0.25f);
        }
        if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE) {
            return new OreColor(1.00f, 0.78f, 0.08f);
        }
        if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) {
            return new OreColor(0.86f, 0.86f, 0.86f);
        }
        if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) {
            return new OreColor(1.00f, 0.43f, 0.16f);
        }
        if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) {
            return new OreColor(1.00f, 0.10f, 0.10f);
        }
        if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) {
            return new OreColor(0.20f, 0.38f, 1.00f);
        }
        if (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) {
            return new OreColor(0.28f, 0.28f, 0.28f);
        }
        if (block == Blocks.NETHER_QUARTZ_ORE) {
            return new OreColor(0.95f, 0.88f, 0.78f);
        }
        if (block == Blocks.ANCIENT_DEBRIS) {
            return new OreColor(0.80f, 0.36f, 0.20f);
        }
        return null;
    }

    private void renderOrePositions(LevelRenderContext context) {
        if (!SeedSightClient.isXrayEnabled() || oreBoxes.isEmpty()) {
            return;
        }

        VertexFormat format = THROUGH_WALLS.getVertexFormatBinding(0);
        if (format == null) {
            return;
        }

        PrimitiveTopology topology = THROUGH_WALLS.getPrimitiveTopology();
        StagedVertexBuffer.Draw draw = BUFFER.appendDraw(
                format,
                topology,
                topology == PrimitiveTopology.QUADS ? RenderSystem.getProjectionType().vertexSorting() : null
        );

        PoseStack matrices = context.poseStack();
        Vec3 camera = context.levelState().cameraRenderState.pos;
        matrices.pushPose();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumer vertices = BUFFER.getVertexBuilder(draw);
        for (OreBox ore : oreBoxes) {
            renderFilledBox(
                    matrices.last().pose(), vertices,
                    ore.x, ore.y, ore.z,
                    ore.x + 1f, ore.y + 1f, ore.z + 1f,
                    ore.red, ore.green, ore.blue, 0.92f
            );
        }
        matrices.popPose();

        BUFFER.upload();
        StagedVertexBuffer.ExecuteInfo info = BUFFER.getExecuteInfo(draw);
        if (info != null) {
            draw(Minecraft.getInstance(), info, THROUGH_WALLS);
        }
        BUFFER.endFrame();
    }

    private static void renderFilledBox(
            Matrix4fc matrix, VertexConsumer buffer,
            float minX, float minY, float minZ,
            float maxX, float maxY, float maxZ,
            float red, float green, float blue, float alpha
    ) {
        // Front
        buffer.addVertex(matrix, minX, minY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, minY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, maxY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, maxY, maxZ).setColor(red, green, blue, alpha);
        // Back
        buffer.addVertex(matrix, maxX, minY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, minY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, maxY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, maxY, minZ).setColor(red, green, blue, alpha);
        // Left
        buffer.addVertex(matrix, minX, minY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, minY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, maxY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, maxY, minZ).setColor(red, green, blue, alpha);
        // Right
        buffer.addVertex(matrix, maxX, minY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, minY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, maxY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, maxY, maxZ).setColor(red, green, blue, alpha);
        // Top
        buffer.addVertex(matrix, minX, maxY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, maxY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, maxY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, maxY, minZ).setColor(red, green, blue, alpha);
        // Bottom
        buffer.addVertex(matrix, minX, minY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, minY, minZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, maxX, minY, maxZ).setColor(red, green, blue, alpha);
        buffer.addVertex(matrix, minX, minY, maxZ).setColor(red, green, blue, alpha);
    }

    private static void draw(Minecraft client, StagedVertexBuffer.ExecuteInfo info, RenderPipeline pipeline) {
        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms().writeTransform(
                RenderSystem.getModelViewMatrixCopy(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX
        );

        RenderTarget target = client.gameRenderer.mainRenderTarget();
        GpuTextureView colorTexture = target.getColorTextureView();
        if (colorTexture == null) {
            return;
        }

        try (RenderPass pass = RenderSystem.getDevice()
                .createCommandEncoder()
                .createRenderPass(
                        () -> "SeedSight ore overlay",
                        colorTexture,
                        Optional.empty(),
                        target.getDepthTextureView(),
                        OptionalDouble.empty()
                )) {
            pass.setPipeline(pipeline);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.setVertexBuffer(0, info.vertexBuffer().slice());
            pass.setIndexBuffer(info.indexBuffer(), info.indexType());
            pass.drawIndexed(info.indexCount(), 1, info.firstIndex(), info.baseVertex(), 0);
        }
    }

    public static void close() {
        BUFFER.close();
    }

    private record OreBox(int x, int y, int z, float red, float green, float blue) {}
    private record OreColor(float red, float green, float blue) {}
}
