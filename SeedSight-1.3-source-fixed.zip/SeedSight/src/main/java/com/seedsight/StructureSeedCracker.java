package com.seedsight;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.function.BooleanSupplier;

/**
 * Standalone Java implementation of the 1.18+ random-spread structure seed solver.
 * It recovers the lower 48 bits used by Java's structure-placement RNG. The
 * client login hash is checked separately to recover the full 64-bit world seed.
 */
public final class StructureSeedCracker {
    private StructureSeedCracker() {}

    private static final long MASK48 = (1L << 48) - 1L;
    private static final int MASK24 = 0x00ff_ffff;
    private static final int TWO24 = 1 << 24;
    private static final long TWO31 = 1L << 31;
    private static final long MULTIPLIER = 0x5deece66dL;
    private static final int MULT_LO = 0xece66d;
    private static final int MULT_HI = 0x5de;
    private static final long ADDEND = 0xbL;
    private static final long REGION_X = 341873128712L;
    private static final long REGION_Z = 132897987541L;
    private static final int MULT_LO_INVERSE = inverseOddModuloPowerOfTwo(MULT_LO, 24);

    public enum Spread { LINEAR, TRIANGULAR }
    public enum Anchor { CHUNK, CORNER, SPILL }

    /** Structure placement constants for the modern Java structure sets. */
    public enum StructureType {
        DESERT_PYRAMID("desert_pyramid", "Desert Pyramid", 32, 8, 14357617, Spread.LINEAR, Anchor.CORNER),
        IGLOO("igloo", "Igloo", 32, 8, 14357618, Spread.LINEAR, Anchor.CORNER),
        JUNGLE_TEMPLE("jungle_temple", "Jungle Temple", 32, 8, 14357619, Spread.LINEAR, Anchor.CORNER),
        SWAMP_HUT("swamp_hut", "Swamp Hut", 32, 8, 14357620, Spread.LINEAR, Anchor.CORNER),
        PILLAGER_OUTPOST("pillager_outpost", "Pillager Outpost", 32, 8, 165745296, Spread.LINEAR, Anchor.CORNER),
        SHIPWRECK("shipwreck", "Shipwreck", 24, 4, 165745295, Spread.LINEAR, Anchor.CHUNK),
        OCEAN_RUIN("ocean_ruin", "Ocean Ruin", 20, 8, 14357621, Spread.LINEAR, Anchor.CHUNK),
        RUINED_PORTAL("ruined_portal", "Ruined Portal", 40, 15, 34222645, Spread.LINEAR, Anchor.SPILL),
        OCEAN_MONUMENT("ocean_monument", "Ocean Monument", 32, 5, 10387313, Spread.TRIANGULAR, Anchor.CORNER),
        WOODLAND_MANSION("woodland_mansion", "Woodland Mansion", 80, 20, 10387319, Spread.TRIANGULAR, Anchor.CHUNK),
        NETHER_COMPLEX("nether_complex", "Nether Fortress / Bastion", 27, 4, 30084232, Spread.LINEAR, Anchor.CHUNK),
        VILLAGE("village", "Village", 34, 8, 10387312, Spread.LINEAR, Anchor.CORNER),
        ANCIENT_CITY("ancient_city", "Ancient City", 24, 8, 20083232, Spread.LINEAR, Anchor.CORNER),
        TRAIL_RUINS("trail_ruins", "Trail Ruins", 34, 8, 83469867, Spread.LINEAR, Anchor.CORNER),
        TRIAL_CHAMBERS("trial_chambers", "Trial Chambers", 34, 12, 94251327, Spread.LINEAR, Anchor.CORNER),
        END_CITY("end_city", "End City", 20, 11, 10387313, Spread.TRIANGULAR, Anchor.CHUNK);

        public final String id;
        public final String displayName;
        public final int spacing;
        public final int separation;
        public final int salt;
        public final Spread spread;
        public final Anchor anchor;

        StructureType(String id, String displayName, int spacing, int separation, int salt, Spread spread, Anchor anchor) {
            this.id = id;
            this.displayName = displayName;
            this.spacing = spacing;
            this.separation = separation;
            this.salt = salt;
            this.spread = spread;
            this.anchor = anchor;
        }

        public int bound() { return spacing - separation; }

        public static StructureType byId(String id) {
            for (StructureType type : values()) {
                if (type.id.equalsIgnoreCase(id) || type.name().equalsIgnoreCase(id)) return type;
            }
            return null;
        }

        public static String idsForHelp() {
            StringBuilder out = new StringBuilder();
            for (StructureType type : values()) {
                if (!out.isEmpty()) out.append(", ");
                out.append(type.id);
            }
            return out.toString();
        }
    }

    /** Chunk-level observation, including small coordinate uncertainty for spill structures. */
    public record Observation(StructureType type, int chunkX, int chunkZ, int spanX, int spanZ,
                              int measuredBlockX, int measuredBlockZ) {
        public static Observation fromBlock(StructureType type, int blockX, int blockZ) {
            int chunkX;
            int chunkZ;
            int spanX = 0;
            int spanZ = 0;
            switch (type.anchor) {
                case CORNER -> {
                    chunkX = Math.floorDiv(blockX + 8, 16);
                    chunkZ = Math.floorDiv(blockZ + 8, 16);
                }
                case SPILL -> {
                    chunkX = Math.floorDiv(blockX, 16);
                    chunkZ = Math.floorDiv(blockZ, 16);
                    spanX = Math.floorMod(blockX, 16) >= 8 ? 1 : 0;
                    spanZ = Math.floorMod(blockZ, 16) >= 8 ? 1 : 0;
                }
                default -> {
                    chunkX = Math.floorDiv(blockX, 16);
                    chunkZ = Math.floorDiv(blockZ, 16);
                }
            }
            return new Observation(type, chunkX, chunkZ, spanX, spanZ, blockX, blockZ);
        }
    }

    public record Progress(String stage, double fraction, String detail) {}
    public record Result(List<Long> structureSeeds, int lowBits, int survivingLowPatterns,
                         long highCandidatesChecked, double informationBits) {}

    private static final class Prepared {
        final int n;
        final boolean powerOfTwo;
        final boolean triangular;
        final int offX;
        final int offZ;
        final int spanX;
        final int spanZ;
        final long c;
        final int cLo;
        final int cHi;
        final int k;
        final double informationBits;

        Prepared(Observation observation, int offX, int offZ, int spanX, int spanZ, long c) {
            this.n = observation.type().bound();
            this.powerOfTwo = (n & (n - 1)) == 0;
            this.triangular = observation.type().spread == Spread.TRIANGULAR;
            this.offX = offX;
            this.offZ = offZ;
            this.spanX = spanX;
            this.spanZ = spanZ;
            this.c = c & MASK48;
            this.cLo = (int) (this.c & MASK24);
            this.cHi = (int) ((this.c >>> 24) & MASK24);
            this.k = (!powerOfTwo && !triangular) ? Integer.numberOfTrailingZeros(n) : 0;
            this.informationBits = axisInformation(n, triangular, offX, spanX)
                    + axisInformation(n, triangular, offZ, spanZ);
        }
    }

    private record FilterStep(int base, int kk, int lo7, int n, int minOffset,
                              int maxOffset, long rejectionLimit) {
        boolean passes(int highSeed24) {
            int highBeforeXor = (highSeed24 + base) & MASK24;
            int highAfterXor = highBeforeXor ^ MULT_HI;
            int newHigh = (int) ((((long) highAfterXor * MULT_LO) + kk) & MASK24);
            int bits = (newHigh << 7) | lo7;
            if (bits >= rejectionLimit) return true; // Full check handles a possible nextInt rejection.
            int offset = bits % n;
            return offset >= minOffset && offset <= maxOffset;
        }

        int highSeedForNewHigh(int newHigh) {
            int beforeXor = (int) (((long) ((newHigh - kk) & MASK24) * MULT_LO_INVERSE) & MASK24);
            return ((beforeXor ^ MULT_HI) - base) & MASK24;
        }

        int firstRerollHigh() {
            return (int) Math.max(0L, Math.floorDiv(rejectionLimit - lo7 + 127L, 128L));
        }
    }

    public static Result crack(List<Observation> observations, BooleanSupplier cancelled,
                                java.util.function.Consumer<Progress> progress) {
        if (observations == null || observations.size() < 3) {
            throw new IllegalArgumentException("Add at least three different structures before cracking.");
        }
        List<Prepared> prepared = prepare(observations);
        if (prepared.size() < 3) throw new IllegalArgumentException("At least three usable structure observations are required.");

        int maxK = 0;
        double infoBits = 0.0;
        for (Prepared p : prepared) {
            maxK = Math.max(maxK, p.k);
            infoBits += p.informationBits;
        }
        if (maxK == 0) {
            throw new IllegalArgumentException("These structures do not provide low-bit lifting. Add a Village, Shipwreck, Temple, Igloo, Swamp Hut, Ancient City, or Ocean Ruin.");
        }
        if (infoBits < 42.0) {
            throw new IllegalArgumentException("Not enough structure information yet (about " + Math.round(infoBits) + " bits). Explore and add more structures; aim for roughly 50 bits or more.");
        }

        int lowBits = 17 + maxK;
        if (lowBits > 24) throw new IllegalArgumentException("Unsupported structure placement bounds for this version.");
        int lowMask = (1 << lowBits) - 1;
        int lowCount = 1 << lowBits;
        int[] lowPatterns = new int[lowCount];
        int lowPatternCount = 0;

        emit(progress, "lifting", 0.0, "Filtering the lowest " + lowBits + " seed bits");
        for (int low = 0; low < lowCount; low++) {
            checkCancelled(cancelled);
            boolean matches = true;
            for (Prepared p : prepared) {
                if (p.k == 0) continue;
                int kMask = (1 << p.k) - 1;
                int start = ((low + p.cLo) & lowMask) ^ (MULT_LO & lowMask);
                long state = (((long) start * (MULT_LO & lowMask)) + ADDEND) & lowMask;
                int x = (int) ((state >>> 17) & kMask);
                if (!matchesLow(x, p.offX, p.spanX, kMask)) { matches = false; break; }
                state = ((state * (MULT_LO & lowMask)) + ADDEND) & lowMask;
                int z = (int) ((state >>> 17) & kMask);
                if (!matchesLow(z, p.offZ, p.spanZ, kMask)) { matches = false; break; }
            }
            if (matches) lowPatterns[lowPatternCount++] = low;
            if ((low & 0x3fff) == 0) emit(progress, "lifting", (double) low / lowCount,
                    "Surviving low-bit patterns: " + lowPatternCount);
        }
        if (lowPatternCount == 0) {
            throw new IllegalArgumentException("No seed candidates fit these structure locations. Check the structure types and measurement points, then add more observations.");
        }

        List<Prepared> filters = prepared.stream()
                .filter(p -> !p.triangular && !p.powerOfTwo && solveStep(p) > 1)
                .sorted((a, b) -> Integer.compare(solveStep(b), solveStep(a)))
                .toList();
        if (filters.isEmpty()) {
            throw new IllegalArgumentException("No efficient linear structure filter is available. Add a Shipwreck, Village, Temple, Igloo, Swamp Hut, Ancient City, or Ocean Ruin.");
        }
        Prepared primary = filters.get(0);
        Prepared secondary = filters.size() > 1 ? filters.get(1) : null;

        Set<Long> found = new HashSet<>();
        long checked = 0;
        int highLowCount = 1 << (24 - lowBits);
        long expectedSteps = (long) lowPatternCount * highLowCount;
        long completedSteps = 0;
        emit(progress, "search", 0.0, "Searching the remaining seed bits (" + lowPatternCount + " low-bit patterns)");

        for (int i = 0; i < lowPatternCount; i++) {
            int low = lowPatterns[i];
            for (int highLow = 0; highLow < highLowCount; highLow++) {
                checkCancelled(cancelled);
                int seedLo = (highLow << lowBits) | low;
                FilterStep first = makeFilterStep(primary, seedLo);
                FilterStep second = secondary == null ? null : makeFilterStep(secondary, seedLo);
                checked += enumerateHighSeeds(first, second, seedLo, prepared, found, cancelled);
                completedSteps++;
                if ((completedSteps & 3L) == 0L) {
                    emit(progress, "search", Math.min(1.0, (double) completedSteps / expectedSteps),
                            "Checked " + completedSteps + " of " + expectedSteps + " low/high blocks; candidates: " + found.size());
                }
            }
        }

        List<Long> results = new ArrayList<>(found);
        results.sort(Long::compareUnsigned);
        emit(progress, "complete", 1.0, "Structure candidates found: " + results.size());
        return new Result(List.copyOf(results), lowBits, lowPatternCount, checked, infoBits);
    }

    private static List<Prepared> prepare(List<Observation> observations) {
        List<Prepared> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Observation observation : observations) {
            StructureType type = observation.type();
            int regionX = Math.floorDiv(observation.chunkX(), type.spacing);
            int regionZ = Math.floorDiv(observation.chunkZ(), type.spacing);
            int offX = observation.chunkX() - regionX * type.spacing;
            int offZ = observation.chunkZ() - regionZ * type.spacing;
            int n = type.bound();
            int spanX = Math.max(0, Math.min(observation.spanX(), n - 1 - offX));
            int spanZ = Math.max(0, Math.min(observation.spanZ(), n - 1 - offZ));
            if (offX >= n || offZ >= n || offX < 0 || offZ < 0) {
                throw new IllegalArgumentException(type.displayName + " cannot start in that chunk. Double-check the type and anchor coordinates.");
            }
            String key = type.salt + ":" + type.spacing + ":" + regionX + ":" + regionZ;
            if (!seen.add(key)) {
                throw new IllegalArgumentException("Two observations are in the same " + type.displayName + " placement region. Add a different structure further away.");
            }
            long c = (regionX * REGION_X + regionZ * REGION_Z + type.salt) & MASK48;
            result.add(new Prepared(observation, offX, offZ, spanX, spanZ, c));
        }
        return result;
    }

    private static long enumerateHighSeeds(FilterStep first, FilterStep second, int seedLo,
                                           List<Prepared> prepared, Set<Long> found,
                                           BooleanSupplier cancelled) {
        int firstReroll = first.firstRerollHigh();
        int g = Math.min(128, Integer.lowestOneBit(first.n));
        int modulus = first.n / g;
        int inverse = modularInverse((128 / g) % modulus, modulus);
        long checks = 0;
        long iterations = 0;

        for (int target = first.minOffset; target <= first.maxOffset; target++) {
            int delta = target - first.lo7;
            if (Math.floorMod(delta, g) != 0) continue;
            int start = modulus == 1 ? 0 : (int) Math.floorMod((long) (delta / g) * inverse, modulus);
            for (int newHigh = start; newHigh < firstReroll; newHigh += modulus) {
                if ((iterations++ & 0x3ffffL) == 0L) checkCancelled(cancelled);
                int highSeed = first.highSeedForNewHigh(newHigh);
                if (second != null && !second.passes(highSeed)) continue;
                long seed48 = ((long) highSeed << 24) | (seedLo & MASK24);
                if (matchesAll(seed48, prepared)) found.add(seed48);
                checks++;
            }
        }
        // Rare java.util.Random rejection cases are retained and verified by the full check.
        for (int newHigh = firstReroll; newHigh < TWO24; newHigh++) {
            if ((newHigh & 0x3ffff) == 0) checkCancelled(cancelled);
            int highSeed = first.highSeedForNewHigh(newHigh);
            if (second != null && !second.passes(highSeed)) continue;
            long seed48 = ((long) highSeed << 24) | (seedLo & MASK24);
            if (matchesAll(seed48, prepared)) found.add(seed48);
            checks++;
        }
        return checks;
    }

    private static FilterStep makeFilterStep(Prepared p, int seedLo) {
        long sum = (long) seedLo + p.cLo;
        int carry0 = (int) (sum >>> 24);
        int lowBeforeXor = (int) (sum & MASK24);
        int lowState = lowBeforeXor ^ MULT_LO;
        long firstProduct = (long) lowState * MULT_LO + ADDEND;
        int carry1 = (int) (firstProduct >>> 24);
        int newLow = (int) (firstProduct & MASK24);
        int lo7 = newLow >>> 17;
        int base = (p.cHi + carry0) & MASK24;
        int kk = (int) (((long) lowState * MULT_HI + carry1) & MASK24);
        long rejectionLimit = TWO31 - (TWO31 % p.n);
        return new FilterStep(base, kk, lo7, p.n, p.offX, p.offX + p.spanX, rejectionLimit);
    }

    private static boolean matchesAll(long seed48, List<Prepared> prepared) {
        for (Prepared p : prepared) {
            Random48 random = new Random48((seed48 + p.c) & MASK48);
            int x;
            int z;
            if (p.triangular) {
                x = (random.nextInt(p.n) + random.nextInt(p.n)) / 2;
                if (x < p.offX || x > p.offX + p.spanX) return false;
                z = (random.nextInt(p.n) + random.nextInt(p.n)) / 2;
            } else {
                x = random.nextInt(p.n);
                if (x < p.offX || x > p.offX + p.spanX) return false;
                z = random.nextInt(p.n);
            }
            if (z < p.offZ || z > p.offZ + p.spanZ) return false;
        }
        return true;
    }

    private static final class Random48 {
        private long state;
        Random48(long seed) { state = (seed ^ MULTIPLIER) & MASK48; }
        int next31() {
            state = (state * MULTIPLIER + ADDEND) & MASK48;
            return (int) (state >>> 17);
        }
        int nextInt(int bound) {
            if ((bound & (bound - 1)) == 0) return (int) (((long) bound * next31()) >>> 31);
            while (true) {
                int bits = next31();
                int value = bits % bound;
                if ((long) bits - value + (bound - 1L) <= Integer.MAX_VALUE) return value;
            }
        }
    }

    private static int solveStep(Prepared p) {
        if (p.triangular || p.powerOfTwo) return 0;
        return p.n / Math.min(128, Integer.lowestOneBit(p.n));
    }

    private static boolean matchesLow(int actual, int expected, int span, int mask) {
        return actual == (expected & mask) || (span > 0 && actual == ((expected + span) & mask));
    }

    private static int modularInverse(int a, int modulus) {
        if (modulus == 1) return 0;
        int value = Math.floorMod(a, modulus);
        for (int candidate = 1; candidate < modulus; candidate++) {
            if ((value * candidate) % modulus == 1) return candidate;
        }
        throw new IllegalStateException("No modular inverse exists for structure filter.");
    }

    private static int inverseOddModuloPowerOfTwo(int value, int bits) {
        long modulus = 1L << bits;
        long a = value & (modulus - 1);
        long t = 0, newT = 1, r = modulus, newR = a;
        while (newR != 0) {
            long quotient = r / newR;
            long tempT = t - quotient * newT;
            t = newT;
            newT = tempT;
            long tempR = r - quotient * newR;
            r = newR;
            newR = tempR;
        }
        if (r != 1) throw new IllegalArgumentException("Multiplier is not invertible.");
        return (int) Math.floorMod(t, modulus);
    }

    private static double axisInformation(int n, boolean triangular, int offset, int span) {
        if (!triangular) return Math.log(n / (double) (span + 1)) / Math.log(2.0);
        double[] probabilities = new double[n];
        for (int a = 0; a < n; a++) for (int b = 0; b < n; b++) probabilities[(a + b) / 2] += 1.0 / (n * (double) n);
        double probability = 0;
        for (int i = offset; i <= offset + span && i < n; i++) probability += probabilities[i];
        return probability <= 0 ? 0 : -Math.log(probability) / Math.log(2.0);
    }

    private static void checkCancelled(BooleanSupplier cancelled) {
        if (Thread.currentThread().isInterrupted() || (cancelled != null && cancelled.getAsBoolean())) {
            throw new CancellationException("Seed search cancelled.");
        }
    }

    private static void emit(java.util.function.Consumer<Progress> progress, String stage,
                             double fraction, String detail) {
        if (progress != null) progress.accept(new Progress(stage, fraction, detail));
    }
}
