package com.seedsight.mixin.client;

import com.seedsight.SeedSightClient;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    @Inject(method = "handleLogin", at = @At("HEAD"))
    private void seedsight$captureLoginHash(ClientboundLoginPacket packet, CallbackInfo ci) {
        SeedSightClient.captureServerHashedSeed(packet.commonPlayerSpawnInfo().seed());
    }
}
