package com.seedsight;

import com.google.common.hash.Hashing;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public final class SeedSightClient implements ClientModInitializer {
    public static final String MOD_ID = "seedsight";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final List<StructureSeedCracker.Observation> OBSERVATIONS = new CopyOnWriteArrayList<>();
    private static final AtomicBoolean CRACKING = new AtomicBoolean(false);
    private static final AtomicBoolean CANCEL_REQUESTED = new AtomicBoolean(false);
    private static volatile boolean xrayEnabled = false;
    private static volatile Long serverHashedSeed = null;
    private static volatile Long multiplayerSeed = null;
    private static volatile List<Long> structureSeedCandidates = List.of();

    private KeyMapping toggleXrayKey;
    private KeyMapping showSeedKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main")
        );

        toggleXrayKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.seedsight.toggle_xray", InputConstants.Type.KEYSYM, InputConstants.KEY_F8, category
        ));
        showSeedKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.seedsight.show_seed", InputConstants.Type.KEYSYM, InputConstants.KEY_F9, category
        ));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            OBSERVATIONS.clear();
            structureSeedCandidates = List.of();
            multiplayerSeed = null;
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            OBSERVATIONS.clear();
            serverHashedSeed = null;
            multiplayerSeed = null;
            structureSeedCandidates = List.of();
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                ClientCommands.literal("seedsight")
                        .then(ClientCommands.literal("add")
                                .then(ClientCommands.argument("type", StringArgumentType.word())
                                        .then(ClientCommands.argument("x", IntegerArgumentType.integer())
                                                .then(ClientCommands.argument("z", IntegerArgumentType.integer())
                                                        .executes(context -> {
                                                            String id = StringArgumentType.getString(context, "type");
                                                            int x = IntegerArgumentType.getInteger(context, "x");
                                                            int z = IntegerArgumentType.getInteger(context, "z");
                                                            return addStructure(context.getSource(), id, x, z);
                                                        })))))
                        .then(ClientCommands.literal("here")
                                .then(ClientCommands.argument("type", StringArgumentType.word())
                                        .executes(context -> {
                                            Minecraft client = Minecraft.getInstance();
                                            if (client.player == null) {
                                                context.getSource().sendFeedback(Component.literal("SeedSight: you must be in a world."));
                                                return 0;
                                            }
                                            String id = StringArgumentType.getString(context, "type");
                                            return addStructure(context.getSource(), id,
                                                    client.player.getBlockX(), client.player.getBlockZ());
                                        })))
                        .then(ClientCommands.literal("list").executes(context -> {
                            if (OBSERVATIONS.isEmpty()) {
                                context.getSource().sendFeedback(Component.literal("SeedSight: no structures recorded yet."));
                            } else {
                                context.getSource().sendFeedback(Component.literal("SeedSight observations (block coordinates):"));
                                for (int i = 0; i < OBSERVATIONS.size(); i++) {
                                    var o = OBSERVATIONS.get(i);
                                    context.getSource().sendFeedback(Component.literal((i + 1) + ". "
                                            + o.type().id + " at " + o.measuredBlockX() + ", " + o.measuredBlockZ()
                                            + " (start chunk " + o.chunkX() + ", " + o.chunkZ() + ")"));
                                }
                            }
                            return 1;
                        }))
                        .then(ClientCommands.literal("remove")
                                .then(ClientCommands.argument("index", IntegerArgumentType.integer(1))
                                        .executes(context -> {
                                            int index = IntegerArgumentType.getInteger(context, "index") - 1;
                                            if (index < 0 || index >= OBSERVATIONS.size()) {
                                                context.getSource().sendFeedback(Component.literal("SeedSight: that observation number does not exist."));
                                                return 0;
                                            }
                                            var removed = OBSERVATIONS.remove(index);
                                            context.getSource().sendFeedback(Component.literal("Removed " + removed.type().displayName + " observation."));
                                            return 1;
                                        })))
                        .then(ClientCommands.literal("clear").executes(context -> {
                            OBSERVATIONS.clear();
                            structureSeedCandidates = List.of();
                            context.getSource().sendFeedback(Component.literal("SeedSight: cleared recorded structures."));
                            return 1;
                        }))
                        .then(ClientCommands.literal("status").executes(context -> {
                            String hashState = serverHashedSeed == null ? "not captured" : "captured";
                            String seedState = multiplayerSeed == null ? "not recovered" : "recovered";
                            context.getSource().sendFeedback(Component.literal("SeedSight: " + OBSERVATIONS.size()
                                    + " structure observations; server hash " + hashState + "; full seed " + seedState + "."));
                            return 1;
                        }))
                        .then(ClientCommands.literal("crack").executes(context -> {
                            startCrack(context.getSource());
                            return 1;
                        }))
                        .then(ClientCommands.literal("help").executes(context -> {
                            context.getSource().sendFeedback(Component.literal("Usage: /seedsight add <type> <blockX> <blockZ>"));
                            context.getSource().sendFeedback(Component.literal("Or stand on the structure's measurement point and use /seedsight here <type>."));
                            context.getSource().sendFeedback(Component.literal("Then run /seedsight crack. Types: " + StructureSeedCracker.StructureType.idsForHelp()));
                            return 1;
                        }))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleXrayKey.consumeClick()) {
                xrayEnabled = !xrayEnabled;
                if (client.player != null) {
                    client.player.sendSystemMessage(Component.literal("SeedSight ore overlay: " + (xrayEnabled ? "ON" : "OFF")));
                }
            }
            while (showSeedKey.consumeClick()) showAndSaveSeed(client);
        });

        new OreOverlayRenderer().register();
        LOGGER.info("SeedSight initialized. F8 toggles the ore overlay; F9 displays a recovered seed. Built-in structure cracking: /seedsight help.");
    }

    public static boolean isXrayEnabled() {
        return xrayEnabled;
    }

    /** Captured from the vanilla CommonPlayerSpawnInfo in the multiplayer login packet. */
    public static void captureServerHashedSeed(long hash) {
        serverHashedSeed = hash;
        LOGGER.info("Captured multiplayer biome seed hash from login packet.");
    }

    private static int addStructure(FabricClientCommandSource source,
                                    String id, int blockX, int blockZ) {
        StructureSeedCracker.StructureType type = StructureSeedCracker.StructureType.byId(id);
        if (type == null) {
            source.sendFeedback(Component.literal("Unknown structure type. Use /seedsight help for valid types."));
            return 0;
        }
        StructureSeedCracker.Observation observation = StructureSeedCracker.Observation.fromBlock(type, blockX, blockZ);
        OBSERVATIONS.add(observation);
        source.sendFeedback(Component.literal("Recorded " + type.displayName + " at " + blockX + ", " + blockZ
                + " (start chunk " + observation.chunkX() + ", " + observation.chunkZ() + "). Total: " + OBSERVATIONS.size()));
        return 1;
    }

    private static void startCrack(FabricClientCommandSource source) {
        if (!CRACKING.compareAndSet(false, true)) {
            source.sendFeedback(Component.literal("SeedSight is already running a seed search."));
            return;
        }
        CANCEL_REQUESTED.set(false);
        Long loginHash = serverHashedSeed;
        if (loginHash == null) {
            CRACKING.set(false);
            source.sendFeedback(Component.literal("SeedSight has not captured the server's login hash. Rejoin the server and try again."));
            return;
        }
        List<StructureSeedCracker.Observation> snapshot = List.copyOf(OBSERVATIONS);
        if (snapshot.size() < 3) {
            CRACKING.set(false);
            source.sendFeedback(Component.literal("Add at least three structures first. Try to collect 5–8 accurate observations."));
            return;
        }
        source.sendFeedback(Component.literal("SeedSight: starting built-in structure seed search with " + snapshot.size() + " observations..."));

        Thread worker = new Thread(() -> {
            try {
                StructureSeedCracker.Result result = StructureSeedCracker.crack(snapshot, CANCEL_REQUESTED::get,
                        update -> LOGGER.info("Seed search {} {:.1f}%: {}", update.stage(), update.fraction() * 100.0, update.detail()));
                List<Long> fullSeeds = resolveFullSeeds(result.structureSeeds(), loginHash);
                structureSeedCandidates = result.structureSeeds();
                if (fullSeeds.size() == 1) {
                    long seed = fullSeeds.get(0);
                    multiplayerSeed = seed;
                    boolean saved = saveSeed(seed, "multiplayer (built-in structure cracker)");
                    postMessage("SeedSight recovered the full 64-bit multiplayer seed: " + seed
                            + (saved ? " (saved in config/seedsight-seed.txt)." : " (file save failed; see latest.log)."));
                } else if (fullSeeds.size() > 1) {
                    postMessage("SeedSight found " + fullSeeds.size() + " full-seed hash matches. Add more structure observations to disambiguate.");
                } else {
                    saveStructureCandidates(result.structureSeeds());
                    postMessage("SeedSight found " + result.structureSeeds().size()
                            + " matching 48-bit structure seed candidate(s), but none matched the server's login hash. The server may alter that hash or use custom world generation; a full 64-bit seed is not confirmed. Candidates saved to config/seedsight-structure-seeds.txt.");
                }
            } catch (CancellationException ignored) {
                postMessage("SeedSight: seed search cancelled.");
            } catch (Exception exception) {
                LOGGER.error("Built-in seed search failed", exception);
                postMessage("SeedSight search failed: " + exception.getMessage());
            } finally {
                CRACKING.set(false);
                CANCEL_REQUESTED.set(false);
            }
        }, "SeedSight-Structure-Cracker");
        worker.setDaemon(true);
        worker.start();
    }

    /** Structure placement recovers 48 bits; the vanilla login hash selects the remaining 16. */
    private static List<Long> resolveFullSeeds(List<Long> structureSeeds, Long serverHash) {
        if (serverHash == null) return List.of();
        List<Long> matches = new ArrayList<>();
        for (long low48 : structureSeeds) {
            for (int high16 = 0; high16 < 65536; high16++) {
                long candidate = ((long) high16 << 48) | (low48 & ((1L << 48) - 1));
                if (Hashing.sha256().hashLong(candidate).asLong() == serverHash) {
                    matches.add(candidate);
                    if (matches.size() > 1) return matches;
                }
            }
        }
        return matches;
    }

    private static void showAndSaveSeed(Minecraft client) {
        if (client.player == null) return;
        IntegratedServer integratedServer = client.getSingleplayerServer();
        if (integratedServer != null) {
            long seed = integratedServer.getWorldGenSettings().options().seed();
            multiplayerSeed = seed;
            boolean saved = saveSeed(seed, "single-player");
            client.player.sendSystemMessage(Component.literal("SeedSight single-player seed: " + seed
                    + (saved ? " (saved to config/seedsight-seed.txt)" : " (could not save; see latest.log)")));
            return;
        }
        Long seed = multiplayerSeed;
        if (seed != null) {
            client.player.sendSystemMessage(Component.literal("SeedSight multiplayer seed: " + seed
                    + " (saved in config/seedsight-seed.txt)"));
            return;
        }
        if (!structureSeedCandidates.isEmpty()) {
            client.player.sendSystemMessage(Component.literal("SeedSight has " + structureSeedCandidates.size()
                    + " 48-bit structure candidate(s), but no confirmed full 64-bit seed. Add more structures or use a vanilla-compatible server."));
        } else {
            client.player.sendSystemMessage(Component.literal("SeedSight: no seed recovered yet. Add structure observations with /seedsight add, then run /seedsight crack."));
        }
    }

    /** Writes the seed without touching client/player objects, so it is safe from the search worker. */
    private static boolean saveSeed(long seed, String source) {
        Path seedFile = FabricLoader.getInstance().getConfigDir().resolve("seedsight-seed.txt");
        try {
            Files.createDirectories(seedFile.getParent());
            Files.writeString(seedFile, Long.toString(seed) + System.lineSeparator(), StandardCharsets.UTF_8);
            LOGGER.info("Saved {} seed from {}", seed, source);
            return true;
        } catch (IOException exception) {
            LOGGER.error("Could not save the world seed to {}", seedFile, exception);
            return false;
        }
    }

    private static void saveStructureCandidates(List<Long> candidates) {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("seedsight-structure-seeds.txt");
        try {
            Files.createDirectories(file.getParent());
            List<String> lines = candidates.stream().map(value -> String.format("0x%012x", value)).toList();
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException exception) {
            LOGGER.error("Could not save the structure seed candidates", exception);
        }
    }

    private static void postMessage(String message) {
        Minecraft client = Minecraft.getInstance();
        client.execute(() -> {
            if (client.player != null) client.player.sendSystemMessage(Component.literal(message));
            LOGGER.info(message);
        });
    }
}
