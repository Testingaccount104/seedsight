package com.seedsight;

import net.minecraft.resources.Identifier;

public final class IdentifierHelper {
    private IdentifierHelper() {}

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(SeedSightClient.MOD_ID, path);
    }
}
