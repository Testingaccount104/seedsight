@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed. Install Gradle 9.5.1 or open this folder in IntelliJ IDEA.
  exit /b 1
)
gradle wrapper --gradle-version 9.5.1
if errorlevel 1 exit /b 1
echo Gradle wrapper created. You can now use gradlew.bat build.
