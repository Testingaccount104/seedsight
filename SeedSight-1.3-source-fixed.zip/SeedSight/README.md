# SeedSight — Fabric 26.2

SeedSight is one client-side mod and contains its own structure seed solver; **you do not need to install a second seed-cracking mod**. It still uses the standard Fabric API library required by this project.

## Features

- **F8** toggles the ore overlay.
- **F9** displays the single-player seed or a confirmed multiplayer seed.
- Built-in structure placement solver for modern Java random-spread structures.
- Uses the multiplayer login's SHA-256 seed hash to test the remaining 16 bits after structure placement narrows the seed to 48 bits.
- Saves a confirmed full seed to `.minecraft/config/seedsight-seed.txt`.
- If the server hash is changed or cannot be validated, saves the lower-48-bit structure candidates to `.minecraft/config/seedsight-structure-seeds.txt` instead of pretending one is the full seed.

## Multiplayer use

The built-in collector is manual in this version: a normal client is not given a reliable list of world-generation structure start chunks, so SeedSight asks you to mark structures you discover. SeedSight does not scan every visible building and identify its exact start chunk automatically yet.

1. Join a vanilla-compatible Java 26.2 world.
2. Explore and find naturally generated structures.
3. At the correct reference point for a structure, use `/seedsight here <type>` to record your current X/Z, or `/seedsight add <type> <blockX> <blockZ>` to enter coordinates from F3.
4. Repeat for at least 5–8 different structures in different placement regions. More accurate, varied observations improve the search.
5. Run `/seedsight crack`. The search runs on a background thread so it does not freeze rendering.
6. If the recovered 48-bit structure seed matches the server's login hash, SeedSight saves the confirmed 64-bit world seed. Press **F9** to display it.

### Commands

- `/seedsight help` — show usage and supported structure IDs.
- `/seedsight here <type>` — record your current X/Z as a structure observation.
- `/seedsight add <type> <blockX> <blockZ>` — record explicit block coordinates.
- `/seedsight list` — list recorded observations.
- `/seedsight remove <number>` — remove one observation from the list.
- `/seedsight clear` — clear observations.
- `/seedsight status` — show collected data and seed status.
- `/seedsight crack` — run the built-in solver.

Supported IDs:

`desert_pyramid`, `igloo`, `jungle_temple`, `swamp_hut`, `pillager_outpost`, `shipwreck`, `ocean_ruin`, `ruined_portal`, `ocean_monument`, `woodland_mansion`, `nether_complex`, `village`, `ancient_city`, `trail_ruins`, `trial_chambers`, `end_city`.

### Coordinate accuracy

The coordinate you enter must map to the structure's placement start chunk, not an arbitrary nearby landmark. Use different placement regions; two examples of the same structure set inside one region do not add independent information. The `here` command applies a structure-specific block-to-chunk estimate, so choose a point close to the structure's placement anchor. For shipwrecks, ocean ruins, mansions, fortresses/bastions, and End cities, the selected point must be in the correct start chunk. Ruined portals allow limited uncertainty for structures that can spill across a chunk border. If the structure's true start chunk is unclear, the observation may be wrong and the solver may return no match.

A bad coordinate or wrong structure type can prevent a match. Use `/seedsight list` to inspect what you entered; use `/seedsight remove` or `/seedsight clear` to correct mistakes.

## How full-seed recovery works

Modern Java structure placement uses a 48-bit Java RNG state. Structure placements can therefore identify the lower 48 bits, but structure locations alone cannot distinguish the 65,536 possible 64-bit world seeds that share those bits. SeedSight's built-in solver narrows those candidates with observed placement offsets. It then checks the candidate upper 16 bits against the SHA-256-derived hashed seed sent in the multiplayer login packet. If the server replaces that hash, the full seed cannot be confirmed through this route; SeedSight will keep the result labelled as a 48-bit structure candidate instead.

The solver expects vanilla-compatible modern (1.18+) structure placement settings. Custom datapacks, plugins that relocate or alter structures, non-vanilla terrain generation, or a server that changes the login seed hash can prevent exact recovery.

## X-ray limitation

F8 currently highlights real ore blocks in chunks already sent to your client. Recovering the full seed is now built into SeedSight, but this build does **not yet generate a predictive ore map for chunks that have not been sent to the client**. The seed-recovery feature and loaded-chunk ore overlay are separate parts of the mod.

## Build requirements

- Minecraft 26.2
- JDK 25
- Fabric Loader 0.19.3 or newer
- Fabric API 0.154.0+26.2 or compatible newer 26.2 release
- Fabric Loom 1.17-SNAPSHOT
- Gradle 9.5.1

Open this folder as a Gradle project in IntelliJ IDEA, set the Gradle JVM to JDK 25, and run the `build` task. The mod JAR will be created in `build/libs/`.

## Install

1. Build the project.
2. Install Fabric Loader for Minecraft 26.2 and the matching Fabric API.
3. Put the single `seedsight-1.2.0.jar` file in your Minecraft `mods` folder.
4. Launch the Fabric 26.2 profile.

No separate seed-cracking mod is needed.
